typedef enum {false,true} bool;

extern int __VERIFIER_nondet_int(void);

int main() {
    int i;
    int j;
    i = 0;
    j = 5;
    
    while (i < 100) { i = i+1; }
    
    while (j < 21) { j = j+3; }
    
    return 0;
}
