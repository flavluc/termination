#define NULL ((void*)0)
typedef unsigned long size_t;  // Customize by platform.
typedef long intptr_t; typedef unsigned long uintptr_t;
typedef long scalar_t__;  // Either arithmetic or pointer type.
/* By default, we understand bool (as a convenience). */
typedef int bool;
#define false 0
#define true 1

/* Forward declarations */

/* Type definitions */
typedef  int u_int ;
typedef  int u_char ;

/* Variables and functions */

int create_rand_string(u_char *data, int len, u_int tmp) {
    if(!tmp) tmp++;
    while(len--) {
        tmp = (*data + tmp) % 62;
        if(tmp <= 9) {
            *data = tmp + '0';
        } else if((tmp >= 10) && (tmp <= 35)) {
            *data = (tmp - 10) + 'A';
        } else {
            *data = (tmp - 36) + 'a';
        }
        data++;
    }
    return(tmp << 1);
}