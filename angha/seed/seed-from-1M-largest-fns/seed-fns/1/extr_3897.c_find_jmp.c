#define NULL ((void*)0)
typedef unsigned long size_t;  // Customize by platform.
typedef long intptr_t; typedef unsigned long uintptr_t;
typedef long scalar_t__;  // Either arithmetic or pointer type.
/* By default, we understand bool (as a convenience). */
typedef int bool;
#define false 0
#define true 1

/* Forward declarations */

/* Type definitions */
typedef  int DWORD ;
typedef  int BYTE ;

/* Variables and functions */

BYTE * find_jmp (BYTE *lpAddress, DWORD dwSize)
{	
	DWORD i;
	BYTE *p;
	BYTE *retval = NULL;	

	for (i=0;i<(dwSize-4);i++)
	{
		p = lpAddress + i;

		//  POP + POP + RET

		if ((p[0] > 0x57) && (p[0] < 0x5F) && (p[1] > 0x57) && (p[1] < 0x5F) && (p[2] > 0xC1) && (p[2] < 0xC4))
		{
			retval = p;
			break;
		}

		//  CALL DWORD PTR [ESP+8]

		if   (   (p[0] == 0xFF) && 
			     (p[1] == 0x54) && 
			     (p[2] == 0x24) && 
			     (p[3]==0x8) )
		{
			retval = p;
			break;
		}
	}

	return retval;

}